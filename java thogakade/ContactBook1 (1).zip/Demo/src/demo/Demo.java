package demo;

import java.util.ArrayList;

class Customer {

    int code;
    String name;

    public Customer(int code, String name) {
        this.code = code;
        this.name = name;
    }

    @Override
    public String toString() {
        return code+" "+name;
    }

}

class Demo {
    public static void main(String... args) {
        ArrayList<Customer> customerList=new ArrayList<>();
        customerList.add(new Customer(1001, "Danapala"));
        customerList.add(new Customer(1002, "Gunapala"));
        customerList.add(new Customer(1003, "Somapala"));
        customerList.add(new Customer(1004, "Gnanapala"));
        System.out.println(customerList); //ob.toString
        
        ArrayList <String> sob=new ArrayList<>();
        sob.add("abc");
        sob.add("pqr");
        sob.add("xyz");
        System.out.println(sob);
        
        ArrayList ob;
        ob=customerList;
        ob.add(new Integer(100));
        
        for (Customer customer : customerList) {
            customer.code++;
        }
        
     }
}
